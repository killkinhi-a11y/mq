"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { useAppStore } from "@/store/useAppStore";
import { motion, AnimatePresence } from "framer-motion";
import {
  Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Repeat, Repeat1,
  Shuffle, X, Heart, ThumbsDown, ListMusic, Music, ChevronLeft, FileText, ExternalLink, Download, Moon, Clock
} from "lucide-react";
import { formatDuration, searchTracks, type Track } from "@/lib/musicApi";
import TrackCard from "./TrackCard";
import { getAudioElement, resumeAudioContext } from "@/lib/audioEngine";

export default function FullTrackView() {
  const {
    currentTrack, isPlaying, volume, progress, duration,
    shuffle, repeat, togglePlay, nextTrack, prevTrack,
    setVolume, setProgress, setDuration, toggleShuffle, toggleRepeat,
    isFullTrackViewOpen, setFullTrackViewOpen, animationsEnabled,
    toggleLike, toggleDislike, likedTrackIds, dislikedTrackIds,
    similarTracks, setSimilarTracks, similarTracksLoading, setSimilarTracksLoading,
    playTrack, queue, showSimilarRequested, clearShowSimilarRequest,
    showLyricsRequested, clearShowLyricsRequest,
    sleepTimerActive, sleepTimerRemaining, startSleepTimer, stopSleepTimer, updateSleepTimer,
  } = useAppStore();

  const progressRef = useRef<HTMLDivElement>(null);
  const volumeRef = useRef<HTMLDivElement>(null);
  const volumeSectionRef = useRef<HTMLDivElement>(null);
  const waveCanvasRef = useRef<HTMLCanvasElement>(null);
  const waveAnimRef = useRef<number>(0);
  const [isDragging, setIsDragging] = useState(false);
  const [showSimilar, setShowSimilar] = useState(false);
  const [showLyrics, setShowLyrics] = useState(false);
  const [showSleepTimer, setShowSleepTimer] = useState(false);

  // Native wheel handler for volume section (fix passive listener issue)
  useEffect(() => {
    const el = volumeSectionRef.current;
    if (!el) return;
    const handler = (e: WheelEvent) => {
      e.preventDefault();
      e.stopPropagation();
      const delta = e.deltaY > 0 ? -5 : 5;
      useAppStore.getState().setVolume(Math.round(Math.max(0, Math.min(100, useAppStore.getState().volume + delta))));
    };
    el.addEventListener('wheel', handler, { passive: false });
    return () => el.removeEventListener('wheel', handler);
  }, []);

  // Handle showSimilarRequested from store
  useEffect(() => {
    if (showSimilarRequested) {
      setShowSimilar(true);
      setShowLyrics(false);
      clearShowSimilarRequest();
    }
  }, [showSimilarRequested, clearShowSimilarRequest]);

  // Handle showLyricsRequested from store
  useEffect(() => {
    if (showLyricsRequested) {
      setShowLyrics(true);
      setShowSimilar(false);
      clearShowLyricsRequest();
    }
  }, [showLyricsRequested, clearShowLyricsRequest]);

  // Fetch similar tracks
  useEffect(() => {
    if (!currentTrack || !showSimilar) return;
    let cancelled = false;
    const fetchSimilar = async () => {
      setSimilarTracksLoading(true);
      try {
        const query = `${currentTrack.artist}`;
        const res = await fetch(`/api/music/search?q=${encodeURIComponent(query)}&limit=8`);
        const data = await res.json();
        const tracks: Track[] = (data.tracks || []).filter((t: Track) => t.id !== currentTrack.id);
        if (!cancelled) setSimilarTracks(tracks.slice(0, 6));
      } catch {
        if (!cancelled) setSimilarTracks([]);
      } finally {
        if (!cancelled) setSimilarTracksLoading(false);
      }
    };
    fetchSimilar();
    return () => { cancelled = true; };
  }, [currentTrack, showSimilar, setSimilarTracks, setSimilarTracksLoading]);

  // ── Ambient visualization — decorative aurora + wave bars, not tied to audio ──
  useEffect(() => {
    const canvas = waveCanvasRef.current;
    if (!canvas || !isFullTrackViewOpen) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Flowing aurora blobs with color variation
    const blobs = Array.from({ length: 8 }, () => ({
      x: Math.random(),
      y: 0.05 + Math.random() * 0.9,
      radius: 50 + Math.random() * 100,
      phase: Math.random() * Math.PI * 2,
      sx: 0.015 + Math.random() * 0.05,
      sy: 0.01 + Math.random() * 0.04,
      drift: 0.12 + Math.random() * 0.3,
      hueShift: Math.random() * 80 - 40,
    }));

    // Sparkle particles
    const sparkles = Array.from({ length: 40 }, () => ({
      x: Math.random(),
      y: Math.random(),
      size: 0.5 + Math.random() * 2.5,
      phase: Math.random() * Math.PI * 2,
      twinkle: 0.3 + Math.random() * 2,
      vx: (Math.random() - 0.5) * 0.06,
      vy: (Math.random() - 0.5) * 0.04,
    }));

    // Decorative wave bars
    const barCount = 64;
    const wBars = Array.from({ length: barCount }, () => ({
      phase: Math.random() * Math.PI * 2,
      speed: 0.6 + Math.random() * 1.8,
      amp: 0.2 + Math.random() * 0.8,
    }));

    const draw = () => {
      waveAnimRef.current = requestAnimationFrame(draw);
      const dpr = window.devicePixelRatio || 1;
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      if (canvas.width !== w * dpr || canvas.height !== h * dpr) {
        canvas.width = w * dpr;
        canvas.height = h * dpr;
        ctx.scale(dpr, dpr);
      }

      ctx.clearRect(0, 0, w, h);

      const accent = getComputedStyle(document.documentElement).getPropertyValue("--mq-accent").trim() || "#e03131";
      let ar = 224, ag = 49, ab = 49;
      if (accent.startsWith("#") && accent.length >= 7) {
        ar = parseInt(accent.slice(1, 3), 16);
        ag = parseInt(accent.slice(3, 5), 16);
        ab = parseInt(accent.slice(5, 7), 16);
      }

      const t = performance.now() / 1000;

      // Aurora blobs
      for (const bl of blobs) {
        const bx = bl.x + Math.sin(t * bl.sx + bl.phase) * bl.drift;
        const by = bl.y + Math.cos(t * bl.sy + bl.phase * 1.4) * bl.drift * 0.5;
        const px = ((bx % 1) + 1) % 1 * w;
        const py = by * h;
        const breathe = 0.6 + 0.4 * Math.sin(t * 0.35 + bl.phase);
        const rad = bl.radius * breathe;

        const hr = Math.min(255, Math.max(0, ar + bl.hueShift));
        const hg = Math.min(255, Math.max(0, ag + bl.hueShift * 0.6));
        const hb = Math.min(255, Math.max(0, ab - bl.hueShift * 0.4));

        const grad = ctx.createRadialGradient(px, py, 0, px, py, rad);
        grad.addColorStop(0, `rgba(${hr},${hg},${hb},0.12)`);
        grad.addColorStop(0.4, `rgba(${hr},${hg},${hb},0.05)`);
        grad.addColorStop(1, `rgba(${hr},${hg},${hb},0)`);
        ctx.beginPath();
        ctx.arc(px, py, rad, 0, Math.PI * 2);
        ctx.fillStyle = grad;
        ctx.fill();
      }

      // Wave bars at bottom
      const bw = w / barCount;
      for (let i = 0; i < barCount; i++) {
        const bar = wBars[i];
        const val = 0.1 + bar.amp * (0.5 + 0.5 * Math.sin(t * bar.speed + bar.phase));
        const barH = val * h * 0.25;
        const x = i * bw;
        const grad = ctx.createLinearGradient(x, h, x, h - barH);
        grad.addColorStop(0, `rgba(${ar},${ag},${ab},0.18)`);
        grad.addColorStop(1, `rgba(${ar},${ag},${ab},0.02)`);
        ctx.fillStyle = grad;
        ctx.fillRect(x + 1, h - barH, bw - 2, barH);
      }

      // Sparkles
      for (const sp of sparkles) {
        sp.x += sp.vx * 0.0006;
        sp.y += sp.vy * 0.0006;
        if (sp.x < 0) sp.x = 1;
        if (sp.x > 1) sp.x = 0;
        if (sp.y < 0) sp.y = 1;
        if (sp.y > 1) sp.y = 0;

        const px = sp.x * w;
        const py = sp.y * h;
        const tw = 0.15 + 0.85 * Math.pow(Math.max(0, Math.sin(t * sp.twinkle + sp.phase)), 3);
        const alpha = tw * 0.55;
        const size = sp.size * (0.4 + tw * 0.6);

        ctx.beginPath();
        ctx.arc(px, py, size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${ar},${ag},${ab},${alpha})`;
        ctx.fill();
      }

      // Center glow pulse
      const pulseAlpha = 0.05 + 0.04 * Math.sin(t * 0.6);
      const glowRad = Math.max(w, h) * 0.35;
      const glowGrad = ctx.createRadialGradient(w * 0.5, h * 0.5, 0, w * 0.5, h * 0.5, glowRad);
      glowGrad.addColorStop(0, `rgba(${ar},${ag},${ab},${pulseAlpha})`);
      glowGrad.addColorStop(1, `rgba(${ar},${ag},${ab},0)`);
      ctx.beginPath();
      ctx.arc(w * 0.5, h * 0.5, glowRad, 0, Math.PI * 2);
      ctx.fillStyle = glowGrad;
      ctx.fill();
    };
    draw();
    return () => { if (waveAnimRef.current) cancelAnimationFrame(waveAnimRef.current); };
  }, [isFullTrackViewOpen, currentTrack?.id]);

  // ── Sleep timer ──────────────────────────────────────────
  useEffect(() => {
    if (!sleepTimerActive) return;
    const interval = setInterval(updateSleepTimer, 1000);
    return () => clearInterval(interval);
  }, [sleepTimerActive, updateSleepTimer]);

  // Progress drag
  const seekToPosition = useCallback((clientX: number) => {
    if (!progressRef.current || !duration) return;
    const rect = progressRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const pct = Math.max(0, Math.min(1, x / rect.width));
    setProgress(pct * duration);
    const audio = getAudioElement();
    if (audio) audio.currentTime = pct * duration;
  }, [duration, setProgress]);

  const handleProgressMouseDown = useCallback((e: React.MouseEvent) => {
    setIsDragging(true);
    seekToPosition(e.clientX);
    const handleMouseMove = (ev: MouseEvent) => seekToPosition(ev.clientX);
    const handleMouseUp = () => {
      setIsDragging(false);
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
  }, [seekToPosition]);

  const handleProgressTouchStart = useCallback((e: React.TouchEvent) => {
    setIsDragging(true);
    seekToPosition(e.touches[0].clientX);
    const handleTouchMove = (ev: TouchEvent) => {
      ev.preventDefault();
      seekToPosition(ev.touches[0].clientX);
    };
    const handleTouchEnd = () => {
      setIsDragging(false);
      document.removeEventListener("touchmove", handleTouchMove);
      document.removeEventListener("touchend", handleTouchEnd);
    };
    document.addEventListener("touchmove", handleTouchMove, { passive: false });
    document.addEventListener("touchend", handleTouchEnd);
  }, [seekToPosition]);

  const handleVolumeClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!volumeRef.current) return;
    const rect = volumeRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    setVolume(Math.round(Math.max(0, Math.min(100, (x / rect.width) * 100))));
  }, [setVolume]);

  // Download track via fetch+blob
  const handleDownload = useCallback(async () => {
    const track = useAppStore.getState().currentTrack;
    if (!track) return;
    const audio = getAudioElement();
    if (audio && audio.src) {
      try {
        const res = await fetch(audio.src);
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${track.artist} - ${track.title}.mp3`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch {
        const a = document.createElement('a');
        a.href = audio.src;
        a.download = `${track.artist} - ${track.title}.mp3`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
    }
  }, []);

  if (!currentTrack || !isFullTrackViewOpen) return null;

  const progressPct = duration > 0 ? (progress / duration) * 100 : 0;
  const safeLikedIds = Array.isArray(likedTrackIds) ? likedTrackIds : [];
  const safeDislikedIds = Array.isArray(dislikedTrackIds) ? dislikedTrackIds : [];
  const isLiked = currentTrack ? safeLikedIds.includes(currentTrack.id) : false;
  const isDisliked = currentTrack ? safeDislikedIds.includes(currentTrack.id) : false;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex flex-col"
        style={{ backgroundColor: "var(--mq-bg)" }}
      >
        {/* Wave line visualization canvas — behind everything */}
        <canvas
          ref={waveCanvasRef}
          className="absolute inset-0 z-[1] w-full h-full pointer-events-none"
          style={{ opacity: isPlaying ? 0.7 : 0.15, transition: "opacity 0.5s" }}
        />

        {/* Blurred background */}
        <div className="absolute inset-0 z-0" style={{ pointerEvents: "none" }}>
          {currentTrack.cover && (
            <img src={currentTrack.cover} alt="" className="w-full h-full object-cover blur-3xl opacity-20 scale-110" />
          )}
          <div className="absolute inset-0" style={{ backgroundColor: "var(--mq-bg)", opacity: 0.85 }} />
        </div>

        {/* Header */}
        <div className="relative z-10 flex items-center justify-between p-4">
          <motion.button whileTap={{ scale: 0.9 }} onClick={() => { setFullTrackViewOpen(false); setShowSimilar(false); }}
            className="p-2" style={{ color: "var(--mq-text)" }}>
            <ChevronLeft className="w-6 h-6" />
          </motion.button>
          <span className="text-xs px-2 py-1 rounded-full" style={{ backgroundColor: "var(--mq-card)", color: "var(--mq-text-muted)", border: "1px solid var(--mq-border)" }}>
            Сейчас играет
          </span>
          <motion.button whileTap={{ scale: 0.9 }} onClick={handleDownload}
            className="p-2" style={{ color: "var(--mq-text-muted)" }} title="Скачать">
            <Download className="w-5 h-5" />
          </motion.button>
        </div>

        {/* Content */}
        <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 max-w-lg mx-auto w-full">
          {/* Album art — no radial visualization around it */}
          <motion.div
            initial={animationsEnabled ? { scale: 0.8, opacity: 0 } : undefined}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 200 }}
            className="mb-8 flex items-center justify-center"
          >
            <div className="w-56 h-56 sm:w-64 sm:h-64 lg:w-80 lg:h-80 rounded-2xl overflow-hidden shadow-2xl relative z-10"
              style={{ boxShadow: "0 20px 60px rgba(0,0,0,0.5)" }}>
              <img src={currentTrack.cover} alt={currentTrack.album} className="w-full h-full object-cover" />
            </div>
          </motion.div>

          {/* Track info */}
          <div className="text-center mb-6 w-full">
            <h2 className="text-xl font-bold mb-1 truncate" style={{ color: "var(--mq-text)" }}>
              {currentTrack.title}
            </h2>
            <p className="text-sm mb-1 truncate" style={{ color: "var(--mq-text-muted)" }}>
              {currentTrack.artist}
            </p>
            <p className="text-xs truncate" style={{ color: "var(--mq-text-muted)", opacity: 0.7 }}>
              {currentTrack.album}
            </p>
          </div>

          {/* Progress bar */}
          <div className="w-full mb-6">
            <div ref={progressRef}
              onMouseDown={handleProgressMouseDown}
              onTouchStart={handleProgressTouchStart}
              className="w-full h-2 rounded-full cursor-pointer relative"
              style={{ backgroundColor: "var(--mq-border)" }}>
              <div className="h-full rounded-full transition-all duration-100"
                style={{ width: `${progressPct}%`, backgroundColor: "var(--mq-accent)", boxShadow: "0 0 8px var(--mq-glow)" }} />
              <div className="absolute top-1/2 w-4 h-4 rounded-full"
                style={{ left: `${progressPct}%`, backgroundColor: "var(--mq-accent)", transform: "translate(-50%, -50%)", boxShadow: "0 0 8px var(--mq-glow)" }} />
            </div>
            <div className="flex justify-between mt-2">
              <span className="text-xs" style={{ color: "var(--mq-text-muted)" }}>{formatDuration(Math.floor(progress))}</span>
              <span className="text-xs" style={{ color: "var(--mq-text-muted)" }}>{formatDuration(Math.floor(duration))}</span>
            </div>
          </div>

          {/* Action buttons row */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <motion.button whileTap={{ scale: 0.85 }} onClick={() => currentTrack && toggleLike(currentTrack.id, currentTrack)}
              className="w-[38px] h-[38px] rounded-full flex items-center justify-center"
              style={{
                backgroundColor: isLiked ? "rgba(239,68,68,0.15)" : "var(--mq-card)",
                border: `1px solid ${isLiked ? "rgba(239,68,68,0.4)" : "var(--mq-border)"}`,
                color: isLiked ? "#ef4444" : "var(--mq-text-muted)",
              }}>
              <Heart className={`w-[18px] h-[18px] ${isLiked ? "fill-current" : ""}`} />
            </motion.button>
            <motion.button whileTap={{ scale: 0.85 }} onClick={() => currentTrack && toggleDislike(currentTrack.id)}
              className="w-[38px] h-[38px] rounded-full flex items-center justify-center"
              style={{
                backgroundColor: isDisliked ? "rgba(239,68,68,0.15)" : "var(--mq-card)",
                border: `1px solid ${isDisliked ? "rgba(239,68,68,0.4)" : "var(--mq-border)"}`,
                color: isDisliked ? "#ef4444" : "var(--mq-text-muted)",
              }}>
              <ThumbsDown className={`w-[18px] h-[18px] ${isDisliked ? "fill-current" : ""}`} />
            </motion.button>
            <motion.button whileTap={{ scale: 0.85 }} onClick={() => { setShowSimilar(!showSimilar); setShowLyrics(false); }}
              className="w-[38px] h-[38px] rounded-full flex items-center justify-center"
              style={{
                backgroundColor: showSimilar ? "var(--mq-accent)" : "var(--mq-card)",
                border: "1px solid var(--mq-border)",
                color: showSimilar ? "var(--mq-text)" : "var(--mq-text-muted)",
              }}>
              <ListMusic className="w-[18px] h-[18px]" />
            </motion.button>
            <motion.button whileTap={{ scale: 0.85 }} onClick={() => { setShowLyrics(!showLyrics); setShowSimilar(false); }}
              className="w-[38px] h-[38px] rounded-full flex items-center justify-center"
              style={{
                backgroundColor: showLyrics ? "var(--mq-accent)" : "var(--mq-card)",
                border: "1px solid var(--mq-border)",
                color: showLyrics ? "var(--mq-text)" : "var(--mq-text-muted)",
              }}>
              <FileText className="w-[18px] h-[18px]" />
            </motion.button>
            <button onClick={() => setVolume(volume > 0 ? 0 : 70)}
              className="w-[38px] h-[38px] rounded-full flex items-center justify-center"
              style={{
                backgroundColor: "var(--mq-card)",
                border: "1px solid var(--mq-border)",
                color: "var(--mq-text-muted)",
              }}>
              {volume === 0 ? <VolumeX className="w-[18px] h-[18px]" /> : <Volume2 className="w-[18px] h-[18px]" />}
            </button>
            {/* Sleep timer */}
            <div className="relative">
              <motion.button whileTap={{ scale: 0.85 }} onClick={() => setShowSleepTimer(!showSleepTimer)}
                className="w-[38px] h-[38px] rounded-full flex items-center justify-center relative"
                style={{
                  backgroundColor: sleepTimerActive ? "var(--mq-accent)" : "var(--mq-card)",
                  border: `1px solid ${sleepTimerActive ? "var(--mq-accent)" : "var(--mq-border)"}`,
                  color: sleepTimerActive ? "var(--mq-text)" : "var(--mq-text-muted)",
                }}>
                <Moon className="w-[18px] h-[18px]" />
                {sleepTimerActive && (
                  <span className="absolute -top-1 -right-1 min-w-[16px] h-[16px] rounded-full text-[8px] flex items-center justify-center"
                    style={{ backgroundColor: "var(--mq-text)", color: "var(--mq-accent)" }}>
                    {Math.floor(sleepTimerRemaining / 60)}
                  </span>
                )}
              </motion.button>
              <AnimatePresence>
                {showSleepTimer && (
                  <motion.div initial={{ opacity: 0, y: 8, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.95 }}
                    className="fixed inset-0 z-[200] flex items-center justify-center"
                    onClick={() => setShowSleepTimer(false)}>
                    <div className="absolute inset-0 bg-black/40" />
                    <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      className="relative z-10 p-4 rounded-2xl w-56 shadow-xl"
                      style={{ backgroundColor: "var(--mq-card)", border: "1px solid var(--mq-border)" }}
                      onClick={(e) => e.stopPropagation()}>
                      <p className="text-xs font-medium mb-3 text-center" style={{ color: "var(--mq-text-muted)" }}>Таймер сна</p>
                      {sleepTimerActive ? (
                        <div className="space-y-3">
                          <p className="text-lg text-center font-mono" style={{ color: "var(--mq-accent)" }}>
                            {Math.floor(sleepTimerRemaining / 60)}:{(sleepTimerRemaining % 60).toString().padStart(2, "0")}
                          </p>
                          <button onClick={() => { stopSleepTimer(); setShowSleepTimer(false); }}
                            className="w-full flex items-center justify-center gap-1 py-2.5 rounded-xl text-sm"
                            style={{ backgroundColor: "rgba(224,49,49,0.15)", color: "#ff6b6b" }}>
                            <X className="w-4 h-4" /> Отменить
                          </button>
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 gap-2">
                          {[15, 30, 45, 60].map((m) => (
                            <button key={m} onClick={() => { startSleepTimer(m); setShowSleepTimer(false); }}
                              className="flex items-center justify-center gap-1 py-3 rounded-xl text-sm"
                              style={{ backgroundColor: "var(--mq-input-bg)", border: "1px solid var(--mq-border)", color: "var(--mq-text)" }}>
                              <Clock className="w-3.5 h-3.5" /> {m} мин
                            </button>
                          ))}
                        </div>
                      )}
                    </motion.div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Main playback controls */}
          <div className="flex items-center gap-6 mb-4">
            <motion.button whileTap={{ scale: 0.9 }} onClick={toggleShuffle}
              style={{ color: shuffle ? "var(--mq-accent)" : "var(--mq-text-muted)" }}>
              <Shuffle className="w-5 h-5" />
            </motion.button>
            <motion.button whileTap={{ scale: 0.9 }} onClick={prevTrack} style={{ color: "var(--mq-text)" }}>
              <SkipBack className="w-6 h-6" />
            </motion.button>
            <motion.button whileTap={{ scale: 0.85 }} onClick={togglePlay}
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ backgroundColor: "var(--mq-accent)", color: "var(--mq-text)", boxShadow: isPlaying ? "0 0 30px var(--mq-glow)" : "none" }}>
              {isPlaying ? <Pause className="w-7 h-7" /> : <Play className="w-7 h-7 ml-1" />}
            </motion.button>
            <motion.button whileTap={{ scale: 0.9 }} onClick={nextTrack} style={{ color: "var(--mq-text)" }}>
              <SkipForward className="w-6 h-6" />
            </motion.button>
            <motion.button whileTap={{ scale: 0.9 }} onClick={toggleRepeat}
              style={{ color: repeat !== "off" ? "var(--mq-accent)" : "var(--mq-text-muted)" }}>
              {repeat === "one" ? <Repeat1 className="w-5 h-5" /> : <Repeat className="w-5 h-5" />}
            </motion.button>
          </div>

          {/* Volume slider — scroll-safe */}
          <div
            ref={volumeSectionRef}
            className="flex items-center gap-3 w-full max-w-xs"
          >
            <div ref={volumeRef} onClick={handleVolumeClick}
              className="flex-1 h-1.5 rounded-full cursor-pointer" style={{ backgroundColor: "var(--mq-border)" }}>
              <div className="h-full rounded-full" style={{ width: `${volume}%`, backgroundColor: "var(--mq-accent)" }} />
            </div>
            <span className="text-[10px] w-8 text-right" style={{ color: "var(--mq-text-muted)" }}>{Math.round(volume)}%</span>
          </div>
        </div>

        {/* Lyrics panel — slides up from bottom */}
        <AnimatePresence>
          {showLyrics && (
            <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="absolute bottom-0 left-0 right-0 z-20 rounded-t-2xl overflow-hidden"
              style={{ maxHeight: "50vh", backgroundColor: "var(--mq-card)", borderTop: "1px solid var(--mq-border)" }}>
              <div className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-bold" style={{ color: "var(--mq-text)" }}>Текст песни</h3>
                  <button onClick={() => setShowLyrics(false)} style={{ color: "var(--mq-text-muted)" }}>
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="text-center py-8">
                  <FileText className="w-10 h-10 mx-auto mb-3" style={{ color: "var(--mq-text-muted)", opacity: 0.3 }} />
                  <p className="text-sm mb-4" style={{ color: "var(--mq-text-muted)" }}>
                    Текст не найден автоматически
                  </p>
                  <div className="flex items-center justify-center gap-3">
                    <motion.button whileTap={{ scale: 0.95 }}
                      onClick={() => window.open(`https://genius.com/search?q=${encodeURIComponent((currentTrack?.title || "") + " " + (currentTrack?.artist || ""))}`, "_blank")}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs"
                      style={{ backgroundColor: "var(--mq-accent)", color: "var(--mq-text)" }}>
                      <ExternalLink className="w-3 h-3" /> Genius
                    </motion.button>
                    <motion.button whileTap={{ scale: 0.95 }}
                      onClick={() => window.open(`https://www.google.com/search?q=${encodeURIComponent((currentTrack?.title || "") + " " + (currentTrack?.artist || "") + " lyrics текст")}`, "_blank")}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs"
                      style={{ backgroundColor: "var(--mq-input-bg)", border: "1px solid var(--mq-border)", color: "var(--mq-text)" }}>
                      <ExternalLink className="w-3 h-3" /> Google
                    </motion.button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Similar tracks panel */}
        <AnimatePresence>
          {showSimilar && (
            <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="absolute bottom-0 left-0 right-0 z-20 rounded-t-2xl overflow-hidden"
              style={{ maxHeight: "50vh", backgroundColor: "var(--mq-card)", borderTop: "1px solid var(--mq-border)" }}>
              <div className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-bold" style={{ color: "var(--mq-text)" }}>Похожие треки</h3>
                  <button onClick={() => setShowSimilar(false)} style={{ color: "var(--mq-text-muted)" }}>
                    <X className="w-4 h-4" />
                  </button>
                </div>
                {similarTracksLoading ? (
                  <div className="space-y-2">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <div key={i} className="h-12 rounded-xl animate-pulse" style={{ backgroundColor: "var(--mq-input-bg)" }} />
                    ))}
                  </div>
                ) : similarTracks.length > 0 ? (
                  <div className="space-y-1 overflow-y-auto" style={{ maxHeight: "35vh" }}>
                    {similarTracks.map((track, i) => (
                      <TrackCard key={track.id} track={track} index={i} queue={similarTracks} />
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-center py-4" style={{ color: "var(--mq-text-muted)" }}>Не удалось загрузить похожие треки</p>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </AnimatePresence>
  );
}
