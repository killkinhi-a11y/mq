#!/bin/bash
# Build MQ Player as Android TWA (Trusted Web Activity)
# Prerequisites: npm, Java 17+, Android SDK
#
# Usage:
#   1. Install Android SDK: https://developer.android.com/studio
#   2. Set ANDROID_HOME environment variable
#   3. Run this script: bash build-android.sh

set -e

echo "=== MQ Player Android Builder ==="
echo ""

# Check prerequisites
if ! command -v java &> /dev/null; then
    echo "ERROR: Java is required. Install JDK 17+"
    exit 1
fi

if [ -z "$ANDROID_HOME" ]; then
    echo "ERROR: ANDROID_HOME is not set. Install Android SDK and set ANDROID_HOME."
    echo "  export ANDROID_HOME=/path/to/android/sdk"
    exit 1
fi

# Check if the server is running
if curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 | grep -q "000"; then
    echo "WARNING: Server is not running. Start it first: cd /home/z/my-project && npm run build && npx next start -p 3000"
fi

echo "Step 1: Installing Bubblewrap CLI..."
npx @nicolo-ribaudo/chokidar-2 @nicolo-ribaudo/twa --version 2>/dev/null || npm install -g @nicolo-ribaudo/chokidar-2 @nicolo-ribaudo/twa 2>/dev/null || true

echo "Step 2: Initializing TWA project..."
if [ ! -d "android-twa" ]; then
    npx @nicolo-ribaudo/chokidar-2 init --manifest twa-manifest.json || {
        echo "ERROR: Failed to init TWA. Try using https://pwabuilder.com instead."
        exit 1
    }
fi

echo "Step 3: Building APK..."
npx @nicolo-ribaudo/chokidar-2 build || {
    echo "ERROR: Build failed."
    exit 1
}

echo ""
echo "=== Build Complete ==="
echo "APK files are in the android-twa/app/release/ directory:"
ls -la android-twa/app/release/*.apk 2>/dev/null || echo "Check android-twa/ for output files"
echo ""
echo "To install on a device:"
echo "  adb install android-twa/app/release/app-release-signed.apk"
echo ""
echo "Alternatively, use PWABuilder.com:"
echo "  1. Go to https://pwabuilder.com"
echo "  2. Enter your website URL"
echo "  3. Click 'Build My PWA'"
echo "  4. Select 'Android' and download the APK"
